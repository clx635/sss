# BluetoothTerminal

## 本地打包 APK

- Windows：
  - `gradlew.bat :app:assembleDebug`
- macOS/Linux：
  - `./gradlew :app:assembleDebug`

说明：
- 标准 Android 工程需要提交 `gradle/wrapper/gradle-wrapper.jar`。如果你把它删了，本地 `gradlew` 会直接无法运行。
- 本仓库的 GitHub Actions 即使缺少该 JAR，也会自动下载对应 Gradle 版本继续构建。

生成的 APK：
- `app/build/outputs/apk/debug/`

## GitHub Actions

工作流文件：
- `.github/workflows/android-apk.yml`

说明：
- 如果仓库根目录就是 Android 工程，会直接构建
- 如果仓库里只有 zip，会自动解压后在 zip 内寻找 Android 工程再构建
