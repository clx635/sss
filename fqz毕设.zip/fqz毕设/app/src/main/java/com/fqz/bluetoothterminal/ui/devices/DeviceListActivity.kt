package com.fqz.bluetoothterminal.ui.devices

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.bluetooth.BluetoothPermission
import com.fqz.bluetoothterminal.bluetooth.BluetoothSerialService
import com.fqz.bluetoothterminal.databinding.ActivityDeviceListBinding
import com.fqz.bluetoothterminal.ui.chat.ChatActivity
import java.util.LinkedHashMap

class DeviceListActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDeviceListBinding
    private val bluetoothAdapter: BluetoothAdapter? = BluetoothAdapter.getDefaultAdapter()

    private val deviceMap = LinkedHashMap<String, BluetoothDevice>()
    private val adapter = DeviceAdapter { item -> onDeviceClicked(item) }

    private var pendingConnectAddress: String? = null
    private var scanning = false

    private var service: BluetoothSerialService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as? BluetoothSerialService.LocalBinder ?: return
            service = b.getService()
            serviceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            service = null
        }
    }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            updateButtons()
        }

    private val enableBtLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            refreshPaired()
        }

    private val discoveryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothAdapter.ACTION_DISCOVERY_STARTED -> {
                    scanning = true
                    updateButtons()
                }
                BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                    scanning = false
                    updateButtons()
                }
                BluetoothDevice.ACTION_FOUND -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    } ?: return
                    val addr = device.address ?: return
                    deviceMap[addr] = device
                    publishList()
                }
                BluetoothDevice.ACTION_BOND_STATE_CHANGED -> {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    } ?: return
                    val addr = device.address ?: return
                    deviceMap[addr] = device
                    publishList()
                    val bonded = try {
                        device.bondState == BluetoothDevice.BOND_BONDED
                    } catch (_: SecurityException) {
                        false
                    }
                    if (bonded && pendingConnectAddress == addr) {
                        pendingConnectAddress = null
                        connectDevice(addr)
                    }
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDeviceListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recycler.adapter = adapter
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnRefresh.setOnClickListener { refreshPaired() }
        binding.btnScan.setOnClickListener { toggleScan() }

        ensureReceiver()
        bindService(Intent(this, BluetoothSerialService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)

        if (bluetoothAdapter == null) {
            binding.tvHint.text = getString(R.string.label_bluetooth_unsupported)
        } else if (!bluetoothAdapter.isEnabled) {
            enableBluetooth()
        } else {
            refreshPaired()
        }
        updateButtons()
    }

    override fun onDestroy() {
        super.onDestroy()
        if (serviceBound) {
            unbindService(serviceConnection)
        }
        try {
            bluetoothAdapter?.cancelDiscovery()
        } catch (_: SecurityException) {
        }
        runCatching { unregisterReceiver(discoveryReceiver) }
    }

    private fun ensureReceiver() {
        val filter = IntentFilter().apply {
            addAction(BluetoothAdapter.ACTION_DISCOVERY_STARTED)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothDevice.ACTION_BOND_STATE_CHANGED)
        }
        ContextCompat.registerReceiver(this, discoveryReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    private fun enableBluetooth() {
        val i = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
        enableBtLauncher.launch(i)
    }

    private fun refreshPaired() {
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) return
        val connectPerms = BluetoothPermission.connectPermissions()
        if (!BluetoothPermission.hasAll(this, connectPerms)) {
            permissionLauncher.launch(connectPerms)
            return
        }
        val bonded = try {
            adapter.bondedDevices?.toList().orEmpty()
        } catch (_: SecurityException) {
            emptyList()
        }
        bonded.forEach { d ->
            val addr = d.address ?: return@forEach
            deviceMap[addr] = d
        }
        publishList()
    }

    private fun toggleScan() {
        val adapter = bluetoothAdapter ?: return
        if (!adapter.isEnabled) {
            enableBluetooth()
            return
        }
        if (scanning) {
            try {
                adapter.cancelDiscovery()
            } catch (_: SecurityException) {
            }
            scanning = false
            updateButtons()
            return
        }
        val scanPerms = BluetoothPermission.scanPermissions()
        if (!BluetoothPermission.hasAll(this, scanPerms)) {
            permissionLauncher.launch(scanPerms)
            return
        }
        try {
            adapter.cancelDiscovery()
        } catch (_: SecurityException) {
        }
        try {
            adapter.startDiscovery()
        } catch (_: SecurityException) {
        }
    }

    private fun onDeviceClicked(item: DeviceItem) {
        if (bluetoothAdapter == null) return
        if (!bluetoothAdapter.isEnabled) {
            enableBluetooth()
            return
        }
        val connectPerms = BluetoothPermission.connectPermissions()
        if (!BluetoothPermission.hasAll(this, connectPerms)) {
            permissionLauncher.launch(connectPerms)
            return
        }
        val device = deviceMap[item.address] ?: return
        val addr = device.address ?: return
        connectDevice(addr)
    }

    private fun connectDevice(address: String) {
        val svc = service ?: return
        svc.connect(address)
        startActivity(Intent(this, ChatActivity::class.java))
    }

    private fun publishList() {
        val list = deviceMap.values
            .mapNotNull { d ->
                val addr = d.address ?: return@mapNotNull null
                val name = try {
                    d.name
                } catch (_: SecurityException) {
                    null
                } ?: "Unknown"
                val bonded = try {
                    d.bondState == BluetoothDevice.BOND_BONDED
                } catch (_: SecurityException) {
                    false
                }
                DeviceItem(name = name, address = addr, bonded = bonded)
            }
            .sortedWith(compareByDescending<DeviceItem> { it.bonded }.thenBy { it.name })
        adapter.submit(list)
    }

    private fun updateButtons() {
        binding.btnScan.text = if (scanning) getString(R.string.action_stop_scan) else getString(R.string.action_scan)
        val hasScan = BluetoothPermission.hasAll(this, BluetoothPermission.scanPermissions())
        val hasConnect = BluetoothPermission.hasAll(this, BluetoothPermission.connectPermissions())
        binding.btnScan.isEnabled = bluetoothAdapter != null && (hasScan || bluetoothAdapter.isEnabled)
        binding.btnRefresh.isEnabled = bluetoothAdapter != null && (hasConnect || bluetoothAdapter.isEnabled)
    }
}

