package com.fqz.bluetoothterminal.ui.settings

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.widget.ArrayAdapter
import androidx.appcompat.app.AppCompatActivity
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.databinding.ActivitySettingsBinding
import com.fqz.bluetoothterminal.settings.AppSettings
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import org.json.JSONArray
import org.json.JSONObject

class SettingsActivity : AppCompatActivity() {
    private lateinit var binding: ActivitySettingsBinding
    private val testExecutor = Executors.newSingleThreadExecutor()

    private val encodingLabels = listOf("GB2312", "UTF-8", "ASCII")
    private val encodingValues = listOf("GB2312", "UTF-8", Charsets.US_ASCII.name())
    private val lineEndingLabels = listOf("无", "\\n", "\\r\\n")
    private val lineEndingValues = listOf(
        AppSettings.LINE_ENDING_NONE,
        AppSettings.LINE_ENDING_LF,
        AppSettings.LINE_ENDING_CRLF
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        val encodingAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, encodingLabels)
        binding.txEncoding.setAdapter(encodingAdapter)
        binding.rxEncoding.setAdapter(encodingAdapter)

        val lineEndingAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, lineEndingLabels)
        binding.lineEnding.setAdapter(lineEndingAdapter)

        val currentTx = AppSettings.getTxCharset(this).name()
        val currentRx = AppSettings.getRxCharset(this).name()
        val currentLineEnding = AppSettings.getLineEnding(this)
        val parseEnabled = AppSettings.isParseEnabled(this)
        val aiEnabled = AppSettings.isAiEnabled(this)
        val aiEndpoint = AppSettings.getAiEndpoint(this)
        val aiModel = AppSettings.getAiModel(this)
        val aiApiKey = AppSettings.getAiApiKey(this)

        binding.txEncoding.setText(pickEncodingLabel(currentTx), false)
        binding.rxEncoding.setText(pickEncodingLabel(currentRx), false)
        binding.lineEnding.setText(pickLineEndingLabel(currentLineEnding), false)
        binding.switchParse.isChecked = parseEnabled
        binding.switchAi.isChecked = aiEnabled
        binding.aiEndpoint.setText(aiEndpoint)
        binding.aiModel.setText(aiModel)
        binding.aiApiKey.setText(aiApiKey)
        binding.tvAiStatus.text = getString(R.string.label_ai_status_default)

        binding.txEncoding.setOnItemClickListener { _, _, position, _ ->
            val v = encodingValues.getOrNull(position) ?: return@setOnItemClickListener
            AppSettings.setTxEncoding(this, v)
        }

        binding.rxEncoding.setOnItemClickListener { _, _, position, _ ->
            val v = encodingValues.getOrNull(position) ?: return@setOnItemClickListener
            AppSettings.setRxEncoding(this, v)
        }

        binding.lineEnding.setOnItemClickListener { _, _, position, _ ->
            val v = lineEndingValues.getOrNull(position) ?: return@setOnItemClickListener
            AppSettings.setLineEnding(this, v)
        }

        binding.switchParse.setOnCheckedChangeListener { _, checked ->
            AppSettings.setParseEnabled(this, checked)
        }

        binding.switchAi.setOnCheckedChangeListener { _, checked ->
            AppSettings.setAiEnabled(this, checked)
        }

        binding.aiEndpoint.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                AppSettings.setAiEndpoint(this@SettingsActivity, s?.toString().orEmpty())
            }
        })

        binding.aiModel.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                AppSettings.setAiModel(this@SettingsActivity, s?.toString().orEmpty())
            }
        })

        binding.aiApiKey.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) = Unit
            override fun afterTextChanged(s: Editable?) {
                AppSettings.setAiApiKey(this@SettingsActivity, s?.toString().orEmpty())
            }
        })

        binding.btnTestAi.setOnClickListener { testAiNow() }
        binding.btnSave.setOnClickListener { finish() }
    }

    override fun onDestroy() {
        super.onDestroy()
        testExecutor.shutdownNow()
    }

    private fun testAiNow() {
        val endpoint = binding.aiEndpoint.text?.toString().orEmpty().trim()
        val model = binding.aiModel.text?.toString().orEmpty().trim()
        val apiKey = binding.aiApiKey.text?.toString().orEmpty().trim()

        if (endpoint.isBlank()) {
            binding.tvAiStatus.text = "${getString(R.string.label_ai_status_fail)}：AI接口地址为空"
            return
        }
        if (!endpoint.lowercase().contains("/v1/chat/completions")) {
            binding.tvAiStatus.text = "${getString(R.string.label_ai_status_fail)}：仅支持 /v1/chat/completions"
            return
        }
        if (model.isBlank()) {
            binding.tvAiStatus.text = "${getString(R.string.label_ai_status_fail)}：AI模型为空"
            return
        }
        if (apiKey.isBlank()) {
            binding.tvAiStatus.text = "${getString(R.string.label_ai_status_fail)}：AI密钥为空"
            return
        }

        binding.tvAiStatus.text = getString(R.string.label_ai_status_testing)
        binding.btnTestAi.isEnabled = false

        testExecutor.execute {
            val result = runCatching { callOpenAiChatCompletionsPing(endpoint, apiKey, model) }.fold(
                onSuccess = { it },
                onFailure = { e -> TestResult(false, null, e.message ?: e.javaClass.simpleName) }
            )
            runOnUiThread {
                binding.btnTestAi.isEnabled = true
                if (result.ok) {
                    binding.tvAiStatus.text = getString(R.string.label_ai_status_ok)
                } else {
                    val msg = result.message?.take(200).orEmpty()
                    binding.tvAiStatus.text = "${getString(R.string.label_ai_status_fail)}：$msg"
                }
            }
        }
    }

    private data class TestResult(val ok: Boolean, val code: Int?, val message: String?)

    private fun callOpenAiChatCompletionsPing(endpoint: String, apiKey: String, model: String): TestResult {
        val payload = JSONObject()
        payload.put("model", model)
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", "只输出一个JSON对象，不要输出多余文本。"))
        messages.put(JSONObject().put("role", "user").put("content", "请输出：{\"type\":\"ping\",\"ok\":true}"))
        payload.put("messages", messages)
        payload.put("temperature", 0.0)

        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 10000
            readTimeout = 20000
            doInput = true
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("Authorization", "Bearer $apiKey")
        }
        conn.outputStream.use { os ->
            os.write(payload.toString().toByteArray(Charsets.UTF_8))
        }

        val code = conn.responseCode
        val body = runCatching {
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        }.getOrDefault("")

        if (code !in 200..299) {
            return TestResult(false, code, "HTTP $code ${body.take(200)}".trim())
        }
        if (body.isBlank()) return TestResult(false, code, "响应为空")

        val root = runCatching { JSONObject(body) }.getOrNull()
            ?: return TestResult(false, code, "响应不是JSON")
        val content = root
            .optJSONArray("choices")
            ?.optJSONObject(0)
            ?.optJSONObject("message")
            ?.optString("content")
            .orEmpty()
            .trim()
        if (content.isBlank()) return TestResult(true, code, "OK")

        val obj = runCatching { JSONObject(content) }.getOrNull()
        val ok = obj?.optBoolean("ok", true) ?: true
        return TestResult(ok, code, if (ok) "OK" else content)
    }

    private fun pickEncodingLabel(charsetName: String): String {
        val idx = encodingValues.indexOfFirst { it.equals(charsetName, ignoreCase = true) }
            .takeIf { it >= 0 }
            ?: encodingLabels.indexOfFirst { it.equals(charsetName, ignoreCase = true) }.takeIf { it >= 0 }
            ?: 1
        return encodingLabels[idx]
    }

    private fun pickLineEndingLabel(value: String): String {
        val idx = lineEndingValues.indexOf(value).takeIf { it >= 0 } ?: 0
        return lineEndingLabels[idx]
    }
}

