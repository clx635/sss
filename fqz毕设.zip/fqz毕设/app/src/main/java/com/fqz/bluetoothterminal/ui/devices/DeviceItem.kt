package com.fqz.bluetoothterminal.ui.devices

data class DeviceItem(
    val name: String,
    val address: String,
    val bonded: Boolean
)

