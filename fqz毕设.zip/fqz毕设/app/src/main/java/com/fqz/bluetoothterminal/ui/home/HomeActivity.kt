package com.fqz.bluetoothterminal.ui.home

import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.ServiceConnection
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.fqz.bluetoothterminal.R
import com.fqz.bluetoothterminal.bluetooth.BtActions
import com.fqz.bluetoothterminal.bluetooth.BtPrefs
import com.fqz.bluetoothterminal.bluetooth.BtState
import com.fqz.bluetoothterminal.bluetooth.BluetoothSerialService
import com.fqz.bluetoothterminal.databinding.ActivityHomeBinding
import com.fqz.bluetoothterminal.ui.about.AboutActivity
import com.fqz.bluetoothterminal.ui.ai.AiActivity
import com.fqz.bluetoothterminal.ui.chat.ChatActivity
import com.fqz.bluetoothterminal.ui.devices.DeviceListActivity
import com.fqz.bluetoothterminal.ui.settings.SettingsActivity

class HomeActivity : AppCompatActivity() {
    private lateinit var binding: ActivityHomeBinding
    private var service: BluetoothSerialService? = null
    private var serviceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            val b = binder as? BluetoothSerialService.LocalBinder ?: return
            service = b.getService()
            serviceBound = true
            val svc = service ?: return
            updateState(svc.getState(), svc.getConnectedDeviceName(), svc.getConnectedDeviceAddress())
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            serviceBound = false
            service = null
        }
    }

    private val stateReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != BtActions.ACTION_STATE) return
            val s = intent.getIntExtra(BtActions.EXTRA_STATE, BtState.DISCONNECTED)
            val name = intent.getStringExtra(BtActions.EXTRA_DEVICE_NAME)
            val addr = intent.getStringExtra(BtActions.EXTRA_DEVICE_ADDRESS)
            updateState(s, name, addr)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setTitleTextColor(ContextCompat.getColor(this, R.color.md_theme_onBackground))

        binding.btnDevices.setOnClickListener { startActivity(Intent(this, DeviceListActivity::class.java)) }
        binding.btnChat.setOnClickListener { startActivity(Intent(this, ChatActivity::class.java)) }
        binding.btnAi.setOnClickListener { startActivity(Intent(this, AiActivity::class.java)) }
        binding.btnSettings.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        binding.btnAbout.setOnClickListener { startActivity(Intent(this, AboutActivity::class.java)) }

        val lastName = BtPrefs.getLastDeviceName(this)
        val lastAddr = BtPrefs.getLastDeviceAddress(this)
        binding.lastDeviceValue.text = formatDevice(lastName, lastAddr)
        updateBluetoothEnabledHint()
        updateState(BtState.DISCONNECTED, null, null)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(BtActions.ACTION_STATE)
        ContextCompat.registerReceiver(this, stateReceiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
        bindService(Intent(this, BluetoothSerialService::class.java), serviceConnection, Context.BIND_AUTO_CREATE)
        updateBluetoothEnabledHint()
    }

    override fun onStop() {
        super.onStop()
        runCatching { unregisterReceiver(stateReceiver) }
        if (serviceBound) {
            runCatching { unbindService(serviceConnection) }
            serviceBound = false
            service = null
        }
    }

    private fun updateBluetoothEnabledHint() {
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) {
            binding.stateValue.text = getString(R.string.label_bluetooth_unsupported)
            return
        }
        if (!adapter.isEnabled) {
            binding.stateValue.text = getString(R.string.label_bluetooth_off)
        }
    }

    private fun updateState(state: Int, deviceName: String?, deviceAddress: String?) {
        when (state) {
            BtState.CONNECTING -> binding.stateValue.text = getString(R.string.label_connecting)
            BtState.CONNECTED -> binding.stateValue.text = getString(R.string.label_connected)
            else -> {
                val adapter = BluetoothAdapter.getDefaultAdapter()
                binding.stateValue.text = if (adapter != null && adapter.isEnabled) {
                    getString(R.string.label_not_connected)
                } else {
                    getString(R.string.label_bluetooth_off)
                }
            }
        }
        if (!deviceName.isNullOrBlank() || !deviceAddress.isNullOrBlank()) {
            binding.lastDeviceValue.text = formatDevice(deviceName, deviceAddress)
        }
    }

    private fun formatDevice(name: String?, address: String?): String {
        val n = name?.takeIf { it.isNotBlank() } ?: "Unknown"
        val a = address?.takeIf { it.isNotBlank() } ?: "—"
        return "$n ($a)"
    }
}

